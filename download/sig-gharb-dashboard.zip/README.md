# SIG Gharb - Dashboard Inondations

Dashboard interactif de Système d'Information Géographique pour la région du Gharb (Maroc).

## Provinces
- **Kénitra** : 14 projets, 50 MDH, 8 communes
- **Sidi Kacem** : 53 projets, 71 MDH, 11 communes  
- **Sidi Slimane** : 5 projets, 9.3 MDH, 1 commune

## Fonctionnalités
- Carte interactive par province (Leaflet)
- Graphiques de répartition par secteur et commune (Recharts)
- Tableau détaillé des projets (rubrique, projet, consistance, coût)
- Navigation par province avec vue d'ensemble

## Technologies
- Next.js 16 + TypeScript
- Leaflet (cartes interactives)
- Recharts (graphiques)
- Tailwind CSS 4 + shadcn/ui

## Déploiement
Déployé sur [Vercel](https://vercel.com)

```bash
npm install
npm run dev
```
